#include <WiFi.h>
#include <HTTPClient.h>

// ======================================================
// CHANGE THIS FOR EACH ESP32
// ESP32 #1 = "N1"
// ESP32 #2 = "N2"
// ESP32 #3 = "N3"
// ======================================================

String NODE_ID = "N2";


// ======================================================
// WIFI
// ======================================================

const char* WIFI_SSID = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";


// ======================================================
// FLASK SERVER
// ======================================================

// IMPORTANT:
// Use the IP address of the computer running Flask.
// Do NOT use 127.0.0.1 here.

const char* SERVER_URL =
  "http://YOUR_COMPUTER_IP:5000/sensor";


// ======================================================
// SENSOR PINS
// ======================================================

#define VIBRATION_PIN 27
#define FLEX_PIN      34
#define IR_PIN        26


// ======================================================
// SEND INTERVAL
// ======================================================

unsigned long previousMillis = 0;

const unsigned long SEND_INTERVAL = 2000;


// ======================================================
// SETUP
// ======================================================

void setup() {

  Serial.begin(115200);

  delay(1000);

  Serial.println();
  Serial.println("================================");
  Serial.println("      MINE MONITORING NODE");
  Serial.println("================================");

  Serial.print("Node ID: ");
  Serial.println(NODE_ID);


  // ----------------------------------------------------
  // SENSOR SETUP
  // ----------------------------------------------------

  pinMode(VIBRATION_PIN, INPUT);

  pinMode(IR_PIN, INPUT);

  // GPIO34 is input only
  analogReadResolution(12);


  // ----------------------------------------------------
  // CONNECT WIFI
  // ----------------------------------------------------

  WiFi.begin(
    WIFI_SSID,
    WIFI_PASSWORD
  );

  Serial.print("Connecting to WiFi");

  while (WiFi.status() != WL_CONNECTED) {

    delay(500);

    Serial.print(".");
  }

  Serial.println();

  Serial.println("WiFi Connected!");

  Serial.print("ESP32 IP Address: ");

  Serial.println(
    WiFi.localIP()
  );


  Serial.print("Flask Server: ");

  Serial.println(
    SERVER_URL
  );

  Serial.println("================================");
}


// ======================================================
// LOOP
// ======================================================

void loop() {

  if (
    millis() - previousMillis >=
    SEND_INTERVAL
  ) {

    previousMillis = millis();

    sendSensorData();
  }
}


// ======================================================
// READ SENSORS + SEND TO FLASK
// ======================================================

void sendSensorData() {

  // ----------------------------------------------------
  // READ SW-420
  // ----------------------------------------------------

  int vibration =
    digitalRead(VIBRATION_PIN);


  // ----------------------------------------------------
  // READ FLEX SENSOR
  // ----------------------------------------------------

  int flexValue =
    analogRead(FLEX_PIN);


  // ----------------------------------------------------
  // READ IR SENSOR
  // ----------------------------------------------------

  int movement =
    digitalRead(IR_PIN);


  // ----------------------------------------------------
  // DISPLAY SENSOR VALUES
  // ----------------------------------------------------

  Serial.println();
  Serial.println("==============================");

  Serial.print("Node: ");
  Serial.println(NODE_ID);

  Serial.print("Vibration: ");
  Serial.println(vibration);

  Serial.print("Flex: ");
  Serial.println(flexValue);

  Serial.print("Movement: ");
  Serial.println(movement);


  // ----------------------------------------------------
  // CHECK WIFI
  // ----------------------------------------------------

  if (
    WiFi.status() != WL_CONNECTED
  ) {

    Serial.println(
      "WiFi disconnected!"
    );

    WiFi.reconnect();

    return;
  }


  // ----------------------------------------------------
  // CREATE JSON
  // ----------------------------------------------------

  String jsonData = "{";

  jsonData += "\"node_id\":\"";
  jsonData += NODE_ID;
  jsonData += "\",";

  jsonData += "\"vibration\":";
  jsonData += String(vibration);
  jsonData += ",";

  jsonData += "\"flex\":";
  jsonData += String(flexValue);
  jsonData += ",";

  jsonData += "\"movement\":";
  jsonData += String(movement);

  jsonData += "}";


  Serial.println();
  Serial.println("Sending data:");

  Serial.println(jsonData);


  // ----------------------------------------------------
  // HTTP POST
  // ----------------------------------------------------

  HTTPClient http;

  http.begin(SERVER_URL);

  http.addHeader(
    "Content-Type",
    "application/json"
  );


  int httpResponseCode =
    http.POST(jsonData);


  // ----------------------------------------------------
  // RESPONSE
  // ----------------------------------------------------

  Serial.print(
    "HTTP Response Code: "
  );

  Serial.println(
    httpResponseCode
  );


  if (httpResponseCode > 0) {

    String response =
      http.getString();

    Serial.print(
      "Flask Response: "
    );

    Serial.println(response);

  }

  else {

    Serial.print(
      "HTTP Error: "
    );

    Serial.println(
      httpResponseCode
    );
  }


  http.end();

  Serial.println("==============================");
}